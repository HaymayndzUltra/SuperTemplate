from __future__ import annotations

from gate_stub_framework import run_gate_cli


if __name__ == "__main__":
    raise SystemExit(run_gate_cli("validate_gate_11_readiness"))
