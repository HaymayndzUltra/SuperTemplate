from __future__ import annotations

from gate_stub_framework import run_protocol_cli


if __name__ == "__main__":
    raise SystemExit(run_protocol_cli("run_protocol_2_gates"))
